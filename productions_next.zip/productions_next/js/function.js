
$('.menu_icon_sec > a').on('click', function(){
    $('body').addClass('active_menu');
});
$('.cross_icon span').on('click', function(){
    $('body').removeClass('active_menu');
});

$(document).ready(function () {
    $('.nav li a + i').on("click", function (e) {
        e.preventDefault();
        $(this).parent().find('>ul').slideToggle(100);
    });
});

var swiper = new Swiper(".banner_slider", {
    slidesPerView: 1,
    spaceBetween: 0,
	speed: 500,
	loop: true,
	// autoplay: {
	// 	delay: 3000,
	// 	disableOnInteraction: false,
	// },
	navigation: {
        nextEl: ".slider_btn_next",
        prevEl: ".slider_btn_prev",
    }
});



$(window).scroll(function(){
	var sticky = $('header'),
	scroll = $(window).scrollTop();
	if (scroll >= 150){
		sticky.addClass('fixed_header');
		$('body').css("", header_height);
	}
	else {
		sticky.removeClass('fixed_header');
	  $('body').css("", "0");
	  }
  });
